-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2022 at 05:41 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `employeedetails`
--

CREATE TABLE `employeedetails` (
  `EmpID` int(11) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  `ContactNo` varchar(10) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `MailID` varchar(200) NOT NULL,
  `DrivingExp` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeedetails`
--

INSERT INTO `employeedetails` (`EmpID`, `FirstName`, `LastName`, `ContactNo`, `Address`, `MailID`, `DrivingExp`) VALUES
(1, 'Jayesh', ' Kore', '8542623591', '14 A Railway Line, Solapur', 'jayeshk1@gmail.com', 4),
(2, 'Sanjay', ' Patil', '7845623155', 'Sath Rashta, Lashkar, Solapur', 'sanjayp2@gmail.com', 2),
(3, 'Kiran', ' Kokare', '9852673512', 'Mahesh Colony, Shivaji Chowk, Solapur', 'kirank3@gmail.com', 3),
(4, 'Renuka', ' Mali (Cleaner)', '9035481635', 'Gandhi Nagar, Maratha Wasti,Solapur', 'renukam4@gmail.com', 0),
(5, 'Rajesh', ' Jadhav', '9581452619', 'Rupa Bhavani Road, Solapur', 'rajeshj5@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employeesalary`
--

CREATE TABLE `employeesalary` (
  `EmpID` int(11) NOT NULL,
  `EmpName` varchar(200) NOT NULL,
  `CurrentDate` varchar(200) NOT NULL,
  `Month` varchar(200) NOT NULL,
  `WorkedDays` int(11) NOT NULL,
  `SalaryPerDay` int(11) NOT NULL,
  `TotalAmt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeesalary`
--

INSERT INTO `employeesalary` (`EmpID`, `EmpName`, `CurrentDate`, `Month`, `WorkedDays`, `SalaryPerDay`, `TotalAmt`) VALUES
(1, 'Jayesh Kore', '24-12-2021', '11-2021', 15, 500, 7500),
(2, 'Sanjay Patil', '24-12-2021', '11-2021', 10, 400, 4000),
(3, 'Kiran Kokare', '24-12-2021', '11-2021', 8, 200, 1600),
(4, 'Renuka Mali (Cleaner)', '24-12-2021', '11-2021', 30, 70, 2100),
(5, 'Rajesh Jadhav', '24-12-2021', '11-2021', 15, 150, 2250);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Username` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`) VALUES
('Harsha', 'Harsha');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `MaintenanceNumber` int(11) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `PersonRes` varchar(200) NOT NULL,
  `Amount` int(11) NOT NULL,
  `CDate` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`MaintenanceNumber`, `Date`, `Description`, `PersonRes`, `Amount`, `CDate`) VALUES
(1, '20-12-2021', 'Electrical Problem', 'Sanjay Patil', 500, '24-12-2021'),
(2, '23-12-2021', 'Cruser(MH 13 BY 4852) Servicing', 'Jayesh Kore', 3000, '24-12-2021');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `ID` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Number` varchar(200) NOT NULL,
  `Seater` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`ID`, `Name`, `Number`, `Seater`) VALUES
(1, 'Swift', 'MH13 AC 1210', 6),
(2, 'Cruser', 'MH13 BY 4852', 14),
(3, 'Tavera', 'MH13 KH 2203', 7),
(4, 'Traveller', 'MH13 CH 5100', 14),
(5, 'Mini Bus', 'MH13 HA 2508', 12);

-- --------------------------------------------------------

--
-- Table structure for table `vehiclebooking`
--

CREATE TABLE `vehiclebooking` (
  `BID` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `CDate` varchar(200) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Number` varchar(200) NOT NULL,
  `Seater` int(11) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `PricePerKM` int(11) NOT NULL,
  `Source` varchar(200) NOT NULL,
  `Destination` varchar(200) NOT NULL,
  `Distance` int(11) NOT NULL,
  `Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehiclebooking`
--

INSERT INTO `vehiclebooking` (`BID`, `ID`, `CDate`, `Name`, `Number`, `Seater`, `Date`, `PricePerKM`, `Source`, `Destination`, `Distance`, `Amount`) VALUES
(1, 1, '14-12-2021', 'Swift', 'MH13 AC 1210', 6, '15-12-2021', 12, 'Solapur', 'Pune', 225, 2700),
(2, 2, '24-12-2021', 'Cruser', 'MH13 BY 4852', 14, '27-12-2021', 12, 'Solapur', 'Barshi', 71, 852),
(3, 5, '24-12-2021', 'Mini Bus', 'MH13 HA 2508', 12, '30-12-2021', 12, 'Solapur', 'Beed', 180, 2160);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
